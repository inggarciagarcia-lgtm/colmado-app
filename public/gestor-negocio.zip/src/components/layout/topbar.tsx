'use client'

import { Button, buttonVariants } from "@/components/ui/button"
import { CircleUser, Menu, Home, Users, CreditCard, Package, ReceiptText, ArrowDownCircle } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { CompanySwitcher } from "./company-switcher"
import { signOut } from "next-auth/react"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface Company {
  id: string
  name: string
  rnc: string | null
}

export function Topbar({ 
  companies, 
  activeCompany 
}: { 
  companies: Company[]
  activeCompany: Company 
}) {
  return (
    <header className="flex h-14 items-center gap-4 border-b bg-slate-50/40 px-4 lg:h-[60px] lg:px-6 print:hidden">
      {/* Mobile Menu */}
      <Sheet>
        <SheetTrigger className={cn(buttonVariants({ variant: "outline", size: "icon" }), "shrink-0 md:hidden cursor-pointer")}>
          <Menu className="h-5 w-5" />
          <span className="sr-only">Menú</span>
        </SheetTrigger>
        <SheetContent side="left" className="flex flex-col">
          <SheetHeader className="text-left border-b pb-4 mb-4">
            <SheetTitle className="flex items-center gap-2 truncate">
              <ReceiptText className="h-5 w-5 text-emerald-600 shrink-0" />
              <span className="truncate">{activeCompany.name}</span>
            </SheetTitle>
          </SheetHeader>
          <nav className="grid gap-2 text-base font-medium">
            <Link
              href="/"
              className="flex items-center gap-3 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:bg-slate-100"
            >
              <Home className="h-4 w-4" />
              Dashboard
            </Link>
            <Link
              href="/invoices"
              className="flex items-center gap-3 rounded-xl px-3 py-2 font-semibold text-emerald-700 hover:bg-emerald-50"
            >
              <ReceiptText className="h-4 w-4 text-emerald-600" />
              Facturación (NCF)
            </Link>
            <Link
              href="/transactions"
              className="flex items-center gap-3 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:bg-slate-100"
            >
              <CreditCard className="h-4 w-4" />
              Cuentas por Cobrar
            </Link>
            <Link
              href="/payables"
              className="flex items-center gap-3 rounded-xl px-3 py-2 font-semibold text-rose-700 hover:bg-rose-50"
            >
              <ArrowDownCircle className="h-4 w-4 text-rose-600" />
              Cuentas por Pagar
            </Link>
            <Link
              href="/products"
              className="flex items-center gap-3 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:bg-slate-100"
            >
              <Package className="h-4 w-4" />
              Productos
            </Link>
            <Link
              href="/contacts"
              className="flex items-center gap-3 rounded-xl px-3 py-2 text-muted-foreground hover:text-foreground hover:bg-slate-100"
            >
              <Users className="h-4 w-4" />
              Contactos (RNC)
            </Link>
          </nav>
        </SheetContent>
      </Sheet>

      {/* Selector Multi-Empresa destacado en la barra superior */}
      <div className="flex-1 flex items-center">
        <CompanySwitcher companies={companies} activeCompany={activeCompany} />
      </div>

      {/* Menú de Usuario */}
      <DropdownMenu>
        <DropdownMenuTrigger className={cn(buttonVariants({ variant: "secondary", size: "icon" }), "rounded-full cursor-pointer")}>
          <CircleUser className="h-5 w-5" />
          <span className="sr-only">Menú de usuario</span>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel className="truncate max-w-[180px]">{activeCompany.name}</DropdownMenuLabel>
          <DropdownMenuSeparator />
          <Link href="/settings" className="w-full">
            <DropdownMenuItem className="cursor-pointer">Ajustes de Empresas</DropdownMenuItem>
          </Link>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => signOut()} className="cursor-pointer">Cerrar Sesión</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </header>
  )
}
'use client'

import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { ReceiptText, Lock } from "lucide-react"

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    
    try {
      const res = await signIn('credentials', {
        redirect: false,
        email: email.trim(),
        password: password.trim(),
      })

      if (res?.error) {
        setError('Correo o contraseña incorrectos. Verifica que sean correctos.')
        setLoading(false)
      } else {
        // Redirección completa para asegurar cookies y sesión en cualquier dispositivo
        window.location.href = '/'
      }
    } catch (err) {
      setError('Error al iniciar sesión. Inténtalo de nuevo.')
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen w-full items-center justify-center bg-slate-50 p-4">
      <Card className="w-full max-w-sm shadow-lg border-slate-200">
        <CardHeader className="space-y-2 text-center pb-4">
          <div className="flex justify-center pb-2">
            <div className="rounded-2xl bg-emerald-100 p-3 text-emerald-700">
              <ReceiptText className="h-8 w-8" />
            </div>
          </div>
          <CardTitle className="text-2xl font-black text-slate-900">Gestor Negocio</CardTitle>
          <CardDescription className="text-xs">
            Sistema de Facturación Fiscal (DGII), Cuentas e Inventario
          </CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            {error && (
              <div className="p-3 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg text-center">
                {error}
              </div>
            )}
            <div className="space-y-1.5">
              <Label htmlFor="email" className="text-xs font-semibold text-slate-700">
                Correo Electrónico
              </Label>
              <Input 
                id="email" 
                type="email" 
                placeholder="ing.garciagarcia@gmail.com" 
                required 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-xs font-semibold text-slate-700">
                Contraseña
              </Label>
              <Input 
                id="password" 
                type="password" 
                placeholder="••••••"
                required 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </CardContent>
          <CardFooter className="pt-2">
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-11" type="submit" disabled={loading}>
              <Lock className="mr-2 h-4 w-4" />
              {loading ? "Entrando al sistema..." : "Iniciar Sesión"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowDownRight, ArrowUpRight, DollarSign, Users, ArrowRight, Building2 } from "lucide-react"
import { prisma } from "@/lib/prisma"
import { getActiveCompany } from "@/lib/actions/companies"
import Link from "next/link"

export default async function Dashboard() {
  const company = await getActiveCompany()

  const clientsCount = await prisma.client.count({
    where: { companyId: company.id }
  })

  const transactions = await prisma.transaction.findMany({
    where: { companyId: company.id }
  })
  
  const totalCobrar = transactions
    .filter(t => t.type === 'INCOME' && t.status === 'PENDING')
    .reduce((acc, t) => acc + t.amount, 0)
    
  const totalPagar = transactions
    .filter(t => t.type === 'EXPENSE' && t.status === 'PENDING')
    .reduce((acc, t) => acc + t.amount, 0)
    
  const balance = transactions
    .filter(t => t.status === 'PAID')
    .reduce((acc, t) => t.type === 'INCOME' ? acc + t.amount : acc - t.amount, 0)

  const pendingIncomesCount = transactions.filter(t => t.type === 'INCOME' && t.status === 'PENDING').length
  const pendingExpensesCount = transactions.filter(t => t.type === 'EXPENSE' && t.status === 'PENDING').length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900">{company.name}</h1>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
              Empresa Activa
            </span>
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">
            RNC: <span className="font-mono font-medium">{company.rnc || 'Sin RNC'}</span> • Resumen financiero general.
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 md:gap-6 lg:grid-cols-4">
        {/* Balance */}
        <Card className="shadow-xs">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-semibold text-slate-600">
              Balance Neto en Caja
            </CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-black font-mono ${balance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
              RD${balance.toFixed(2)}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Ingresos cobrados - Pagos realizados
            </p>
          </CardContent>
        </Card>

        {/* Por Cobrar */}
        <Link href="/transactions" className="group">
          <Card className="shadow-xs hover:border-emerald-300 transition-all cursor-pointer h-full">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-slate-600 group-hover:text-emerald-700">
                Por Cobrar (Clientes)
              </CardTitle>
              <ArrowUpRight className="h-4 w-4 text-emerald-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-black text-emerald-600 font-mono">+RD${totalCobrar.toFixed(2)}</div>
              <div className="flex items-center justify-between mt-1">
                <p className="text-xs text-muted-foreground">
                  {pendingIncomesCount} {pendingIncomesCount === 1 ? 'factura pendiente' : 'facturas pendientes'}
                </p>
                <ArrowRight className="h-3 w-3 text-slate-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </CardContent>
          </Card>
        </Link>

        {/* Por Pagar (Cuentas por Pagar) */}
        <Link href="/payables" className="group">
          <Card className="shadow-xs hover:border-rose-300 transition-all cursor-pointer h-full border-l-4 border-l-rose-500">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-slate-600 group-hover:text-rose-700">
                Por Pagar (Proveedores)
              </CardTitle>
              <ArrowDownRight className="h-4 w-4 text-rose-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-black text-rose-600 font-mono">-RD${totalPagar.toFixed(2)}</div>
              <div className="flex items-center justify-between mt-1">
                <p className="text-xs text-muted-foreground font-medium text-rose-600">
                  {pendingExpensesCount} {pendingExpensesCount === 1 ? 'factura por pagar' : 'facturas por pagar'}
                </p>
                <ArrowRight className="h-3 w-3 text-rose-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </CardContent>
          </Card>
        </Link>

        {/* Directorio */}
        <Link href="/contacts" className="group">
          <Card className="shadow-xs hover:border-indigo-300 transition-all cursor-pointer h-full">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-semibold text-slate-600 group-hover:text-indigo-700">
                Contactos y RNC
              </CardTitle>
              <Users className="h-4 w-4 text-indigo-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-black text-slate-900 font-mono">{clientsCount}</div>
              <div className="flex items-center justify-between mt-1">
                <p className="text-xs text-muted-foreground">
                  Clientes y Proveedores
                </p>
                <ArrowRight className="h-3 w-3 text-slate-400 group-hover:translate-x-1 transition-transform" />
              </div>
            </CardContent>
          </Card>
        </Link>
      </div>
    </div>
  )
}
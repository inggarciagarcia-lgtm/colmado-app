import { getProducts, deleteProduct } from "@/lib/actions/products"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ProductDialog } from "@/components/products/product-dialog"
import { Trash2, Package } from "lucide-react"

export default async function ProductsPage() {
  const products = await getProducts()

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Catálogo de Productos e Inventario</h1>
          <p className="text-sm text-muted-foreground">Administra tus artículos, precios, stock y estado de ITBIS (Gravado o Exento).</p>
        </div>
        <ProductDialog />
      </div>

      <div className="rounded-md border bg-white">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Producto</TableHead>
              <TableHead>Descripción</TableHead>
              <TableHead>Impuesto ITBIS</TableHead>
              <TableHead className="text-right">Stock Disponible</TableHead>
              <TableHead className="text-right">Precio Unitario RD$</TableHead>
              <TableHead className="text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center h-24 text-muted-foreground">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <Package className="h-6 w-6 text-slate-400" />
                    <span>No hay productos registrados todavía.</span>
                  </div>
                </TableCell>
              </TableRow>
            ) : (
              products.map((p) => (
                <TableRow key={p.id}>
                  <TableCell className="font-semibold text-slate-900">{p.name}</TableCell>
                  <TableCell className="text-muted-foreground text-xs">{p.description || '-'}</TableCell>
                  <TableCell>
                    {p.hasItbis ? (
                      <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold bg-blue-100 text-blue-800">
                        ITBIS 18%
                      </span>
                    ) : (
                      <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold bg-slate-100 text-slate-700 border">
                        Exento (0%)
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${
                      p.stock > 5 ? 'bg-emerald-100 text-emerald-800' : p.stock > 0 ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                    }`}>
                      {p.stock} unid.
                    </span>
                  </TableCell>
                  <TableCell className="text-right font-bold font-mono text-base">RD${p.price.toFixed(2)}</TableCell>
                  <TableCell className="text-right">
                    <form action={deleteProduct.bind(null, p.id)}>
                      <Button variant="ghost" size="icon" className="text-rose-500 hover:text-rose-600 hover:bg-rose-50">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </form>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}